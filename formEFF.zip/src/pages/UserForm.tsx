import { FormProvider } from '@/context/FormContext';
import { SubmissionProvider } from '@/context/SubmissionContext';
import FormContainer from '@/components/FormContainer';
import Waves from '@/components/Waves';

const UserForm = () => {
  return (
    <div className="relative min-h-screen">
      <div className="pointer-events-none fixed inset-0 z-0">
        <Waves
          lineColor="#E809FF"
          backgroundColor="transparent"
          waveSpeedX={0.02}
          waveSpeedY={0.01}
          waveAmpX={40}
          waveAmpY={20}
          friction={0.9}
          tension={0.01}
          maxCursorMove={120}
          xGap={12}
          yGap={36}
        />
      </div>
      <div className="relative z-10">
        <FormProvider>
          <SubmissionProvider>
            <FormContainer userMode={true} />
          </SubmissionProvider>
        </FormProvider>
      </div>
    </div>
  );
};

export default UserForm;