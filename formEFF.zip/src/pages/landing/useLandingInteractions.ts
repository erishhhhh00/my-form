import { useEffect } from 'react';

export const useLandingInteractions = () => {
  useEffect(() => {
    const header = document.querySelector('header');
    const navLinks = document.querySelector('.nav-links');
    const menuBtn = document.querySelector('.mobile-menu-btn');

    const onMenuClick = () => {
      navLinks?.classList.toggle('active');
    };

    menuBtn?.addEventListener('click', onMenuClick);

    const checkVisibility = () => {
      const elements = document.querySelectorAll('.service-card, .project-card');
      elements.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight - 150) {
          el.classList.add('visible');
        }
      });
    };

    checkVisibility();
    window.addEventListener('scroll', checkVisibility);

    const onAnchorClick = (e: Event) => {
      const target = e.currentTarget as HTMLAnchorElement;
      const href = target.getAttribute('href');
      if (!href || !href.startsWith('#') || href === '#') return;
      e.preventDefault();
      const targetEl = document.querySelector(href);
      if (targetEl) {
        window.scrollTo({ top: (targetEl as HTMLElement).offsetTop - 80, behavior: 'smooth' });
        navLinks?.classList.remove('active');
      }
    };

    const anchors = document.querySelectorAll('a[href^="#"]');
    anchors.forEach((a) => a.addEventListener('click', onAnchorClick));

    const onScroll = () => {
      if (!header) return;
      if (window.scrollY > 100) {
        (header as HTMLElement).style.padding = '15px 5%';
        (header as HTMLElement).style.background = 'rgba(0,0,0,0.95)';
      } else {
        (header as HTMLElement).style.padding = '20px 5%';
        (header as HTMLElement).style.background = 'rgba(0,0,0,0.9)';
      }
    };

    window.addEventListener('scroll', onScroll);

    return () => {
      menuBtn?.removeEventListener('click', onMenuClick);
      window.removeEventListener('scroll', checkVisibility);
      window.removeEventListener('scroll', onScroll);
      anchors.forEach((a) => a.removeEventListener('click', onAnchorClick));
    };
  }, []);
};


