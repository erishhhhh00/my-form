import React from 'react';
import { Shield, Menu } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header>
      <div className="header-container">
        <a href="#home" className="logo">
          <Shield />
          SafetyProjects
        </a>
        <nav>
          <button className="mobile-menu-btn" aria-label="Open menu">
            <Menu />
          </button>
          <div className="nav-links">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#projects">Projects</a>
            <a href="#contact">Contact</a>
          </div>
        </nav>
      </div>
    </header>
  );
};


