import React from 'react';
import Waves from '@/components/Waves';

export const Footer: React.FC = () => {
  return (
    <footer style={{ position: 'relative', overflow: 'hidden' }}>
      <div className="pointer-events-none" style={{ position: 'absolute', inset: 0, zIndex: 0 }}>
        <Waves
          lineColor="#ffffff33"
          backgroundColor="transparent"
          waveSpeedX={0.02}
          waveSpeedY={0.01}
          waveAmpX={40}
          waveAmpY={20}
          friction={0.9}
          tension={0.01}
          maxCursorMove={120}
          xGap={12}
          yGap={36}
        />
      </div>
      <div className="footer-content" style={{ position: 'relative', zIndex: 1 }}>
        <div className="footer-column">
          <h3>SafetyProjects</h3>
          <p>Your trusted partner for comprehensive industrial safety solutions. We are committed to creating safer work environments through innovation and expertise.</p>
          <div className="social-links">
            <a href="#" aria-label="Facebook">f</a>
            <a href="#" aria-label="Twitter">t</a>
            <a href="#" aria-label="LinkedIn">in</a>
            <a href="#" aria-label="Instagram">ig</a>
          </div>
        </div>
        <div className="footer-column">
          <h3>Quick Links</h3>
          <ul className="footer-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About Us</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
        <div className="footer-column">
          <h3>Our Services</h3>
          <ul className="footer-links">
            <li><a href="#">Safety Training</a></li>
            <li><a href="#">Risk Assessment</a></li>
            <li><a href="#">Safety Equipment</a></li>
            <li><a href="#">Compliance Audits</a></li>
            <li><a href="#">Emergency Planning</a></li>
          </ul>
        </div>
        <div className="footer-column">
          <h3>Newsletter</h3>
          <p>Subscribe to our newsletter to receive updates on safety standards and industry insights.</p>
          <div className="form-group">
            <input type="email" className="form-control" placeholder="Your email address" />
            <button className="btn btn-primary" style={{ marginTop: 10, width: '100%' }}>Subscribe</button>
          </div>
        </div>
      </div>
      <div className="copyright" style={{ position: 'relative', zIndex: 1 }}>
        <p>© 2023 SafetyProjects. All Rights Reserved.</p>
      </div>
    </footer>
  );
};


