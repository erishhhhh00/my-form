import React from 'react';

const ProjectCard: React.FC<{ title: string; subtitle: string; }> = ({ title, subtitle }) => (
  <div className="project-card">
    <div className="project-img">
      <span>{title}</span>
    </div>
    <div className="project-overlay">
      <h3>{title}</h3>
      <p>{subtitle}</p>
    </div>
  </div>
);

export const Projects: React.FC = () => {
  return (
    <section className="section" id="projects">
      <h2 className="section-title">Our Projects</h2>
      <div className="projects-grid">
        <ProjectCard title="Manufacturing Facility Safety" subtitle="Complete safety overhaul for a large manufacturing plant" />
        <ProjectCard title="Construction Site Safety" subtitle="Safety implementation for a high-rise construction project" />
        <ProjectCard title="Chemical Plant Safety" subtitle="Hazardous material handling and safety protocols" />
        <ProjectCard title="Oil & Gas Safety" subtitle="Comprehensive safety solutions for offshore drilling operations" />
      </div>
    </section>
  );
};


