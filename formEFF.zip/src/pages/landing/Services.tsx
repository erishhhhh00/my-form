import React from 'react';
import { HardHat, ClipboardCheck, Wrench, FileText, Headset, AlertTriangle } from 'lucide-react';

const ServiceCard: React.FC<{ icon: React.ReactNode; title: string; desc: string; }> = ({ icon, title, desc }) => (
  <div className="service-card">
    <div className="service-icon">{icon}</div>
    <h3>{title}</h3>
    <p>{desc}</p>
  </div>
);

export const Services: React.FC = () => {
  return (
    <section className="section" id="services">
      <h2 className="section-title">Our Services</h2>
      <div className="services-grid">
        <ServiceCard icon={<HardHat />} title="Safety Training" desc="Comprehensive training programs designed to educate your workforce on safety protocols, emergency procedures, and hazard recognition." />
        <ServiceCard icon={<ClipboardCheck />} title="Risk Assessment" desc="Thorough evaluation of workplace hazards and development of risk mitigation strategies to prevent accidents and injuries." />
        <ServiceCard icon={<Wrench />} title="Safety Equipment" desc="Supply and installation of high-quality safety equipment including PPE, fire suppression systems, and emergency signage." />
        <ServiceCard icon={<FileText />} title="Compliance Audits" desc="Detailed audits to ensure your facility meets all regulatory requirements and industry safety standards." />
        <ServiceCard icon={<Headset />} title="Safety Consulting" desc="Expert guidance on developing safety policies, procedures, and management systems tailored to your organization." />
        <ServiceCard icon={<AlertTriangle />} title="Emergency Planning" desc="Development and implementation of comprehensive emergency response plans for various workplace scenarios." />
      </div>
    </section>
  );
};


