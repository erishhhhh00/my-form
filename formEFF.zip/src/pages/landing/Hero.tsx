import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="hero" id="home">
      <div className="hero-content">
        <h1>Industrial Safety Solutions for a Secure Workplace</h1>
        <p>
          We provide comprehensive safety solutions to protect your workforce and ensure regulatory
          compliance. Our expertise spans across multiple industries with a focus on innovation and
          reliability.
        </p>
        <div className="hero-btns">
          <a href="#services" className="btn btn-primary">Our Services</a>
          <a href="#contact" className="btn btn-secondary">Contact Us</a>
        </div>
      </div>
      <div className="hero-shapes">
        <div className="shape shape-1" />
        <div className="shape shape-2" />
        <div className="shape shape-3" />
      </div>
    </section>
  );
};


