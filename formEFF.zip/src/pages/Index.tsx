import React from 'react';
import './index.css';
import { useLandingInteractions } from './landing/useLandingInteractions';
import { Header } from './landing/Header';
import { Hero } from './landing/Hero';
import { About } from './landing/About';
import { Services } from './landing/Services';
import { Projects } from './landing/Projects';
import { Contact } from './landing/Contact';
import { Footer } from './landing/Footer';
import Waves from '@/components/Waves';
import LiquidChrome from '@/components/LiquidChrome';

const Index: React.FC = () => {
  useLandingInteractions();
  return (
    <div className="relative landing min-h-screen">
      <div className="pointer-events-none fixed inset-0 z-0">
        <Waves
          lineColor="#E809FF"
          backgroundColor="transparent"
          waveSpeedX={0.02}
          waveSpeedY={0.01}
          waveAmpX={40}
          waveAmpY={20}
          friction={0.9}
          tension={0.01}
          maxCursorMove={120}
          xGap={12}
          yGap={36}
        />
      </div>
      <div className="relative z-10">
        <Header />
        <Hero />
        <About />
        <Services />
        <Projects />
        <Contact />
        <Footer />
      </div>
    </div>
  );
};

export default Index;